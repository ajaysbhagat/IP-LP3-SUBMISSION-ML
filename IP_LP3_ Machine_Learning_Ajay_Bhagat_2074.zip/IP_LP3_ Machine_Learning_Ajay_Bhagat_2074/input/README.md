*data_creator.py* will create **color-block** images here for the testing purpose

all the images present in this folder will be passed to ***indentifier.py*** for identification purpose