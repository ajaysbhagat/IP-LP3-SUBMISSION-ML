# LP3-Color-Identifier 

This is a Color-Identifier based on tensorflow and keras.

- Input images are to be placed in input folder
- Images are to be of 200x200 resolution


(Made for a 'Learning Program 3' exercise provided by *Cloud Counselage*)
